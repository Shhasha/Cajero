package Cajero;

import javax.swing.*;

//import Test.traducir;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;


public class Registro extends JFrame {
	
	//private static String cajeroAutm = "", bienvenido = "", botonNumUsuario = "", botonPin = "", botonCancelar = "", botonBorrar = "", botonAceptar = "", botonCrearCuenta = "", botonSalir = "", MostrarSpanish,MostrarEnglish ; // Declara variables estáticas para título, botón aceptar y botón cancelar
	private ArrayList<String> lineas = new ArrayList<>(); // Declara un ArrayList para almacenar las líneas del archivo
	
	private JLabel lblcajeroAutm; 
	private JLabel lblbienvenido;
	private JLabel lblbotonNumUsuario;
	private JLabel lblbotonPin;
	private JButton btnbotonCancelar;
	private JButton btnbotonBorrar;
	private JButton btnbotonAceptar;
	private JButton btnbotonCrearCuenta;
	private JButton btnbotonSalir;
	private JButton btnMostrarSpanish;
	private JButton btnMostrarEnglish;
	
	
	
    private JTextField textField_numUsuario;
    private JPasswordField textField_pin; //textField_pin
    private JTextField mensajeLabel = new JTextField();//guarda el mensaje que emerge en caso de que el usuario no haya llenado sus datos
    private JTextField text_montoDeposito;
    private JTextField textFieldActivo; // JTextField activo
    
    //Botones
    private JRadioButton rbtnBolivianos;//1
    private JRadioButton rbtnDolares;//2
    private JRadioButton rbtnEuros;//3
    private JButton btnAceptar;
    
    
    //Para revisar los usuarios en .txt
    private int numeroUsuarios = 0;// Variable para almacenar el número de usuarios leído del archivo contador.txt
    private String rutaArchivo = "contador.txt";
    
    
    private String usuarioCorrespondiente; //IMPORTANTE, DATO GLOBAL usuarioCorrespondiente que es el numero de archivo que contiene usuarioX.txt que ayudara a abrir otro archivo mostrando los datos de ese usuario
    //Además es una variable que aparecera solamente si el usuario inicia sesion, cuando cierre sesion deberia desaparecer junto al .txt, guarda tanto el numero de usuario para buscar en los registros como también
    //la elección del tipo de cuenta, 1 bs, 2 $ y 3 E
    private int eleccionCuenta; //puede ser 1, 2 o 3
    private String eleccionIdioma = "esp";
    
    public Registro() {
    	

    	setSize(900, 800);//definimos el tamaño de mi ventana
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
    	//Cargamos el archivo en español 
    	cargarArchivo("spanish.txt", lineas); // Carga el contenido del archivo "spanish.txt" en el ArrayList lineas
        //cambiarVariables(lineas); // Cambia las variables estáticas con el contenido del ArrayList lineas
        
        
    	setSize(900, 800);//definimos el tamaño de mi ventana
        getContentPane().setBackground(new Color(37, 37, 37));
        getContentPane().setLayout(null);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(120, 171, 165));
        panel.setBounds(10, 11, 827, 696);
        getContentPane().add(panel);
        panel.setLayout(null);

        JPanel panel_1 = new JPanel();
        panel_1.setBackground(new Color(37, 37, 37));
        panel_1.setBounds(10, 413, 807, 245);
        panel.add(panel_1);
        panel_1.setLayout(null);

        JPanel panel_7 = new JPanel();
        panel_7.setBackground(new Color(192, 192, 192));
        panel_7.setBounds(10, 11, 553, 221);
        panel_1.add(panel_7);
        panel_7.setLayout(null);
        
        
      //BOTON 1
        JButton btn_1 = new JButton("1"); 					// Creamos un botón con el texto "1"
        btn_1.setBounds(27, 11, 89, 38);      				// Configuración de la posición y tamaño del botón
        btn_1.addActionListener(new ActionListener() { 		// Añadimos un ActionListener al botón para manejar su acción
            public void actionPerformed(ActionEvent e) {	// Método que se ejecutará al presionar el botón
            	escribirNumero("1");						// Llamamos al método escribirNumero con el número "1"
            }
        });
        panel_7.add(btn_1);
        
        //BOTON 4
        JButton btn_4 = new JButton("4");
        btn_4.setBounds(27, 60, 89, 38);
        btn_4.addActionListener(new ActionListener() { 		// Añadimos un ActionListener al botón para manejar su acción
            public void actionPerformed(ActionEvent e) {	// Método que se ejecutará al presionar el botón
            	escribirNumero("4");						// Llamamos al método escribirNumero con el número "1"
            }
        }); 
        panel_7.add(btn_4);

        //BOTON 7
        JButton btn_7 = new JButton("7");
        btn_7.setBounds(27, 109, 89, 38);
        btn_7.addActionListener(new ActionListener() { 	
	        public void actionPerformed(ActionEvent e) {	// Método que se ejecutará al presionar el botón
	        	escribirNumero("7");						// Llamamos al método escribirNumero con el número "1"
	        }
	    });
        panel_7.add(btn_7);
        
        //BOTON 2
        JButton btn_2 = new JButton("2");
        btn_2.setBounds(126, 11, 89, 38);
        btn_2.addActionListener(new ActionListener() { 		// Añadimos un ActionListener al botón para manejar su acción
            public void actionPerformed(ActionEvent e) {	// Método que se ejecutará al presionar el botón
            	escribirNumero("2");						// Llamamos al método escribirNumero con el número "1"
            }
        }); 
        panel_7.add(btn_2);
    
        //BOTON 5
        JButton btn_5 = new JButton("5");
        btn_5.setBounds(126, 60, 89, 38);
        btn_5.addActionListener(new ActionListener() { 		// Añadimos un ActionListener al botón para manejar su acción
            public void actionPerformed(ActionEvent e) {	// Método que se ejecutará al presionar el botón
            	escribirNumero("5");						// Llamamos al método escribirNumero con el número "1"
            }
        }); 
        panel_7.add(btn_5);
        
        //BOTON 8
        JButton btn_8 = new JButton("8");
        btn_8.setBounds(126, 109, 89, 38);
        btn_8.addActionListener(new ActionListener() { 		// Añadimos un ActionListener al botón para manejar su acción
            public void actionPerformed(ActionEvent e) {	// Método que se ejecutará al presionar el botón
            	escribirNumero("8");						// Llamamos al método escribirNumero con el número "1"
            }
        }); 
        panel_7.add(btn_8);
        
        //BOTON 3
        JButton btn_3 = new JButton("3");
        btn_3.setBounds(225, 11, 89, 38);
        btn_3.addActionListener(new ActionListener() { 		// Añadimos un ActionListener al botón para manejar su acción
            public void actionPerformed(ActionEvent e) {	// Método que se ejecutará al presionar el botón
            	escribirNumero("3");						// Llamamos al método escribirNumero con el número "1"
            }
        }); 
        panel_7.add(btn_3);
        
        //BOTON 6
        JButton btn_6 = new JButton("6");
        btn_6.setBounds(225, 60, 89, 38);
        btn_6.addActionListener(new ActionListener() { 		// Añadimos un ActionListener al botón para manejar su acción
            public void actionPerformed(ActionEvent e) {	// Método que se ejecutará al presionar el botón
            	escribirNumero("6");						// Llamamos al método escribirNumero con el número "1"
            }
        }); 
        panel_7.add(btn_6);
        
        //BOTON 9
        JButton btn_9 = new JButton("9");
        btn_9.setBounds(225, 109, 89, 38);
        btn_9.addActionListener(new ActionListener() { 		// Añadimos un ActionListener al botón para manejar su acción
            public void actionPerformed(ActionEvent e) {	// Método que se ejecutará al presionar el botón
            	escribirNumero("9");						// Llamamos al método escribirNumero con el número "1"
            }
        }); 
        panel_7.add(btn_9);
        
        //BOTON 0
        JButton btn_0 = new JButton("0");
        btn_0.setBounds(126, 158, 89, 38);
        btn_0.addActionListener(new ActionListener() { 		// Añadimos un ActionListener al botón para manejar su acción
            public void actionPerformed(ActionEvent e) {	// Método que se ejecutará al presionar el botón
            	escribirNumero("0");						// Llamamos al método escribirNumero con el número "1"
            }
        }); 
        panel_7.add(btn_0);
        
        
        
       
        btnbotonCancelar = new JButton("Cancelar");
        btnbotonCancelar.setBounds(414, 11, 128, 38);
        btnbotonCancelar.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				borrarTodo();
				
			}
		});
        panel_7.add(btnbotonCancelar);

        btnbotonBorrar = new JButton("Borrar");
        btnbotonBorrar.setBounds(414, 60, 128, 38);
        btnbotonBorrar.addActionListener(new ActionListener() { 		// Añadimos un ActionListener al botón para manejar su acción
            public void actionPerformed(ActionEvent e) {			// Método que se ejecutará al presionar el botón
            	borrarNumero();										// Llamamos al método borrarNumero al darle clic al boton
            }
        }); 
        panel_7.add(btnbotonBorrar);
        

        btnbotonAceptar = new JButton("Aceptar");
        btnbotonAceptar.setBounds(414, 109, 128, 38);
        btnbotonAceptar.addActionListener(new ActionListener() { 	// Añadimos un ActionListener al botón para manejar su acción
            public void actionPerformed(ActionEvent e) {			// Método que se ejecutará al presionar el botón
            	faltanDatos();										// Llamamos al método faltanDatos al darle clic al boton
            	//LeerNumArchivo();
            	
            	
            }
        }); 
        panel_7.add(btnbotonAceptar);

        btnbotonSalir = new JButton("Salir");
        btnbotonSalir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	setVisible(false);           	
            }
        });
        btnbotonSalir.setBounds(668, 194, 129, 38);
        panel_1.add(btnbotonSalir);
        
        btnbotonCrearCuenta = new JButton("Crear Cuenta");
        btnbotonCrearCuenta.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	setVisible(false);
            	CrearCuenta crearCuenta = new CrearCuenta();
            	crearCuenta.setVisible(true);
            }
        });
        btnbotonCrearCuenta.setBounds(669, 138, 128, 38);
        panel_1.add(btnbotonCrearCuenta);

        
        JPanel panel_3 = new JPanel();
        panel_3.setForeground(new Color(0, 0, 0));
        panel_3.setBackground(new Color(37, 37, 37));
        panel_3.setBounds(10, 81, 807, 321);
        panel.add(panel_3);
        panel_3.setLayout(null);

        JPanel panel_5 = new JPanel();
        panel_5.setBackground(new Color(228, 228, 228));
        panel_5.setBounds(10, 11, 552, 299);
        panel_3.add(panel_5);
        panel_5.setLayout(null);

        JPanel panel_4 = new JPanel();
        panel_4.setBackground(new Color(192, 192, 192));
        panel_4.setBounds(26, 72, 498, 216);
        panel_5.add(panel_4);
        panel_4.setLayout(null);

        JPanel panel_6 = new JPanel();
        panel_6.setBackground(new Color(210, 255, 204));
        panel_6.setBounds(10, 41, 478, 163);
        panel_4.add(panel_6);
        panel_6.setLayout(null);
        
        JLabel lblNewLabel_1 = new JLabel("Por favor ingrese sus datos:");
        lblNewLabel_1.setBounds(10, 11, 241, 14);
        panel_4.add(lblNewLabel_1);
        
        lblbotonNumUsuario = new JLabel("Número de usuario");
        lblbotonNumUsuario.setBounds(20, 11, 191, 14);
        panel_6.add(lblbotonNumUsuario);
        
        lblbotonPin = new JLabel("Contraseña");
        lblbotonPin.setBounds(20, 57, 104, 14);
        panel_6.add(lblbotonPin);
        
        //TEXTFIELD NUSUARIO
        textField_numUsuario = new JTextField(); //Escribir número usuario 
        textField_numUsuario.setBounds(54, 32, 356, 14);
        textField_numUsuario.addMouseListener(new MouseAdapter() {
            // Método que se ejecuta cuando se hace clic en el primer JTextField
            public void mouseClicked(MouseEvent e) {
            	textFieldActivo = textField_numUsuario; // textField_numUsuario será igual al activo textFieldActivo
            }
        });
        // Agregar el primer JTextField al JFrame
        panel_6.add(textField_numUsuario);
        
        //TEXTFIELD PIN
        textField_pin = new JPasswordField(); //Escribir pin
        textField_pin.setBounds(54, 73, 356, 14);
        textField_pin.addMouseListener(new MouseAdapter() {
            // Método que se ejecuta cuando se hace clic en el primer JTextField
            public void mouseClicked(MouseEvent e) {
            	textFieldActivo = textField_pin; // Asignar el primer JTextField como activo
            }
        });
        // Agregar el primer JTextField al JFrame
        panel_6.add(textField_pin);
        
        
        lblbienvenido = new JLabel("BIENVENIDO"); //"Bienvenido o Welcome"Le pasamos el label y la variable que almacena su dato
        lblbienvenido.setHorizontalAlignment(SwingConstants.LEFT);
        lblbienvenido.setForeground(Color.LIGHT_GRAY);
        lblbienvenido.setFont(new Font("Tahoma", Font.BOLD, 24));
        lblbienvenido.setBackground(Color.LIGHT_GRAY);
        lblbienvenido.setBounds(26, 21, 498, 40);
        panel_5.add(lblbienvenido);
            
        JPanel panel_2 = new JPanel();
        panel_2.setBounds(10, 11, 807, 59);
        panel.add(panel_2);
        panel_2.setBackground(new Color(255, 255, 255));
        panel_2.setLayout(null);

        lblcajeroAutm = new JLabel("CAJERO AUTOMÁTICO"); //"CAJERO AUTOMATICO O ATM"
        lblcajeroAutm.setBackground(new Color(192, 192, 192));
        lblcajeroAutm.setHorizontalAlignment(SwingConstants.CENTER);
        lblcajeroAutm.setForeground(new Color(192, 192, 192));
        lblcajeroAutm.setFont(new Font("Tahoma", Font.BOLD, 24));
        lblcajeroAutm.setBounds(97, 11, 633, 40);
        panel_2.add(lblcajeroAutm);

        
        //BOTONES DE SELECCIÓN
        JLabel lblbotonPin_1 = new JLabel("Ingrese la cuenta que desea:");
        lblbotonPin_1.setBounds(20, 98, 207, 14);
        ButtonGroup group = new ButtonGroup();
        
        //3. Establecer la posición y el tamaño del botón de radio.
		//Los parámetros (323, 116) especifican la posición (x, y) del botón en el contenedor.
		//Los parámetros (87, 40) especifican el tamaño (ancho, alto) del botón.
        
        
        
        rbtnBolivianos = new JRadioButton("Bolivianos");
        rbtnBolivianos.setBackground(new Color(210, 255, 204));
        rbtnBolivianos.setBounds(20, 116, 87, 40);
        
        rbtnDolares = new JRadioButton("Dolares");
        rbtnDolares.setBackground(new Color(210, 255, 204));
        rbtnDolares.setBounds(173, 116, 87, 40);
        
        rbtnEuros = new JRadioButton("Euros");
        rbtnEuros.setBackground(new Color(210, 255, 204));
        rbtnEuros.setBounds(323, 116, 87, 40);
        
        group.add(rbtnBolivianos);
        group.add(rbtnDolares);        
        group.add(rbtnEuros);
        panel_6.add(rbtnEuros);
        panel_6.add(rbtnDolares);
        panel_6.add(rbtnBolivianos);//Esta línea añade el JRadioButton al JPanel, lo que permite que el botón de radio sea visible y funcional dentro del panel.
        
        panel_6.add(lblbotonPin_1);//Esta línea añade el JLabel al JPanel, lo que permite que la etiqueta sea visible dentro del panel.
        
        // Añadir ActionListener a cada JRadioButton
        rbtnBolivianos.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.out.println("Se seleccionó Bolivianos");
                eleccionCuenta = 1;
            }
        });

        rbtnDolares.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.out.println("Se seleccionó Dolares");
                eleccionCuenta = 2;
            }
        });

        rbtnEuros.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.out.println("Se seleccionó Euros");
                eleccionCuenta = 3;
            }
        });
    }   
        

    // Método para cargar el contenido de un archivo de texto en una lista
    public static void cargarArchivo(String name, ArrayList<String> lineas) { // Define un método estático para cargar un archivo de texto
        File archivo = new File(name); // Crea un nuevo objeto File con el nombre del archivo
        lineas.clear(); // Borra el contenido actual del ArrayList lineas
        try (BufferedReader lector = new BufferedReader(new FileReader(archivo))) { // Abre un BufferedReader para leer el archivo
            String linea; // Declara una variable para almacenar cada línea del archivo
            while ((linea = lector.readLine()) != null) { // Lee cada línea del archivo hasta que no haya más líneas
                lineas.add(linea); // Agrega la línea al ArrayList lineas
            }
        } catch (IOException e) { // Captura cualquier excepción de tipo IOException
            System.err.println("Error al cargar el archivo: " + e.getMessage()); // Imprime un mensaje de error en caso de excepción
        }
    }

  
   
    // Método para escribir un número en el JTextField que seleccionemos de los 2 que hay 
    private void escribirNumero(String numero) {  // txt_saldo es el JTextField de saldo para mostrar los números
    	if (textFieldActivo != null) {    		
            textFieldActivo.setText(textFieldActivo.getText() + numero); // Agrega "4" al JTextField activo
            /*String textoActual = textField_numUsuario.getText(); // Obtenemos el texto actual del JTextField
            textField_numUsuario.setText(textoActual + numero);  // Concatenamos el número presionado al texto actual y lo seteamos en el JTextField
        	*/
    	}    	
    }
    
    // Método para borrar un número en el JTextField que seleccionemos de los 2 que hay 
    private void borrarNumero() {  // txt_saldo es el JTextField de saldo para mostrar los números
        String textoActual = textFieldActivo.getText(); // Obtenemos el texto actual del JTextField
        if (textFieldActivo != null) {  
        	if (textoActual.length() > 0) { // Verificar que la cadena no esté vacía
                String textoNuevo = textoActual.substring(0, textoActual.length() - 1); // Obtener la cadena sin el último carácter
                textFieldActivo.setText(textoNuevo); // Establecer el nuevo texto en el JTextField
                /*
                 Este método substring de la clase String toma dos argumentos. El primer argumento es el índice inicial (0 en este caso) y 
                 el segundo argumento es el índice final (en este caso, textoActual.length() - 1). Esto devuelve una subcadena de textoActual 
                 que comienza en el índice 0 y va hasta el índice textoActual.length() - 1, excluyendo este último. Por lo tanto, la subcadena 
                 resultante es textoActual sin su último carácter.
                 */
            }
        }
    }
    
    //Metodo que borra el contenido de ambos JTextField
    private void borrarTodo() {
    	textField_pin.setText(""); // Establecer el nuevo texto en el JTextField mandandole un String vacio (nada)
    	textField_numUsuario.setText("");
    }
    
    //Método que comprueba que ambos JTextField esten llenos
    private void faltanDatos() {
    	if (textField_numUsuario.getText().isEmpty() || textField_pin.getText().isEmpty() 
    	        || (!rbtnBolivianos.isSelected() && !rbtnDolares.isSelected() && !rbtnEuros.isSelected())) {
    	    mensajeLabel.setText("Por favor, complete todos los campos.");
    	    JOptionPane.showMessageDialog(null, mensajeLabel.getText());
    	    
    	    
    	}
    	else {
    		
    		RevisarCredenciales();//Si todos los campos estan llenados nos vamos a este método para ver si algun usuario cuenta con los datos que se ingresaron
    	}
    	
    	//System.out.println("la eleccion fue:" + eleccionCuenta);   
    }
    
    
    private int LeerNumArchivo() {
    	System.out.println("LeerNumArchivo()");
    	int cantidadUsuarios = 0;
    	//System.out.println(cantidadUsuarios);
    	try {
            // Abre el archivo para lectura
            BufferedReader reader = new BufferedReader(new FileReader(rutaArchivo));

            // Lee la primera línea del archivo
            String linea = reader.readLine();

            // Cierra el BufferedReader después de leer
            reader.close();

            // Convierte la línea leída a entero y la almacena en la variable 'numero'
            if (linea != null) {
            	cantidadUsuarios = Integer.parseInt(linea);
            	System.out.println("La cantidad de Usuarios es de " + (cantidadUsuarios-1));
            }

            // Retorno del número leído
            return cantidadUsuarios;

        } catch (IOException e) {
            // Maneja cualquier excepción de entrada/salida que pueda ocurrir
            System.out.println("Error al leer el archivo: " + e.getMessage());
        } catch (NumberFormatException e) {
            // Maneja cualquier excepción de formato de número que pueda ocurrir
            System.out.println("El contenido del archivo no es un número válido: " + e.getMessage());
        }
  
        // En caso de error, retorna 0 por defecto    	
        return 0;
        
    }
    
    //MÉTODO QUE CREA EL ARCHIVO usuarioCorrespondiente.txt EN EL QUE SE GUARDA LOS DATOS DE REGISTRO DEL USUARIO, COMO SU NÚMERO PARA BUSCAR SU ARCHIVO (cont) 
    private void RevisarCredenciales() { //Aqui al revisar las credenciales, obtendremos usuarioCorrespondiente que es el numero de archivo que contiene usuarioX.txt que ayudara a abrir otro archivo mostrando los datos de ese usuario
    	
    	numeroUsuarios = (LeerNumArchivo()-1); //Aqui conseguimos la cantidad de usuario
    	int cont = 1;
    	String nombreArchivo;
    	String registrarIniSesion;
    	String numUsuario = textField_numUsuario.getText();
        String pin = textField_pin.getText();
        usuarioCorrespondiente = "usuarioCorrespondiente.txt"; //IMPORTANTE, nombre del archivo que tiene almacenado el numero de usuario que inicia sesión
        System.out.println("RevisarCredenciales()");
        
        boolean datosCorrectos = false;
        
    	while(cont <= numeroUsuarios) {
    		nombreArchivo = "usuario" + cont + ".txt";    
    		registrarIniSesion = "movimientos" + cont + ".txt";   
    		String linea; // Declara una variable para almacenar cada línea leída del archivo
    		//textField_numUsuario.getText().isEmpty() || textField_pin.getText().isEmpty()
    		
    		try {
                // Abre el archivo para lectura
                BufferedReader reader = new BufferedReader(new FileReader(nombreArchivo));

                boolean usuarioEncontrado = false;
                boolean pinEncontrado = false;

                // Lee cada línea del archivo hasta llegar al final o hasta encontrar las coincidencias
                while ((linea = reader.readLine()) != null && !linea.isEmpty()) {
                    if (linea.equals(numUsuario)) {
                        usuarioEncontrado = true;
                    }
                    if (linea.equals(pin)) {
                        pinEncontrado = true;
                    }
                }
                
                

                // Verifica si ambos datos fueron encontrados
                if (usuarioEncontrado && pinEncontrado) {
                	// Obtener la fecha y hora actuales
            		LocalDateTime fechaHoraActual = LocalDateTime.now();
            		// Formatear la fecha y hora
            		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            		String fechaHoraFormateada = null;
            		
            		// COLOCAR ESO EN TODOS LOS FRAMES PARA REGISTRAR LOS MOVIMIENTOS
					fechaHoraFormateada = fechaHoraActual.format(formatter);
                	String mensaje = "Se inicio sesion el: " + fechaHoraFormateada; 
					try (BufferedWriter writer = new BufferedWriter(new FileWriter(registrarIniSesion, true))) {
			            writer.write(mensaje);
			            writer.newLine(); // Escribir una nueva línea después del mensaje
			        } catch (IOException e) {
			            e.printStackTrace();
			        }
					
                	
                	datosCorrectos = true;
                    //System.out.println("Los datos se encontraron con éxito.");
                    while ((linea = reader.readLine()) != null) {
                        System.out.println(linea);
                    }
                    try {
                    	FileWriter writer = new FileWriter(usuarioCorrespondiente); // Abre el archivo para escribir, si no existe, lo crea
                    	// Escribe el número en el archivo
                        writer.write(String.valueOf(cont + "\n" +eleccionIdioma)); // Convierte el número a una cadena y lo escribe en el archivo siendo cont el número de usuario y eleccion el tipo de cuenta, 1 bs, 2 $, 3 E
                        
                        // Cierra el FileWriter para asegurar que los datos se escriban correctamente en el archivo
                        writer.close(); // Cierra el archivo para asegurarse de que los datos se escriban correctamente
                        
                        // Imprime un mensaje en la consola indicando que el número se almacenó con éxito
                        //System.out.println("Número " + cont + " almacenado en " + usuarioCorrespondiente); // Muestra un mensaje en la consola confirmando que el número se guardó
                    } catch (IOException e) {
                        // Maneja cualquier excepción de entrada/salida que pueda ocurrir
                        System.out.println("Error al crear el archivo: " + e.getMessage()); // Si ocurre un error, muestra un mensaje en la consola
                    }
                    
                    if(eleccionCuenta == 1) {
                    	setVisible(false);
                    	BolivianosFrame vent = new BolivianosFrame(); //CORREGIR ESTO, NO SE NECESITA YA QUE ESAS VARIABLES DEBEN SER CONSEGUIDAS AL LLAMAR AL ARCHIVO USUARIO.TXT CORRESPONDIENTE
                    	vent.setVisible(true);
                		System.out.println("1");
                	}
                    
                    if(eleccionCuenta == 2) {
                    	setVisible(false);
                    	DolaresFrame vent = new DolaresFrame(); //CORREGIR ESTO, NO SE NECESITA YA QUE ESAS VARIABLES DEBEN SER CONSEGUIDAS AL LLAMAR AL ARCHIVO USUARIO.TXT CORRESPONDIENTE
                    	vent.setVisible(true);
                    	System.out.println("2");
                    }
                    
                    if(eleccionCuenta == 3) {
                    	setVisible(false);
                    	EuroFrame vent = new EuroFrame(); //CORREGIR ESTO, NO SE NECESITA YA QUE ESAS VARIABLES DEBEN SER CONSEGUIDAS AL LLAMAR AL ARCHIVO USUARIO.TXT CORRESPONDIENTE
                    	vent.setVisible(true);
                    	System.out.println("3");
                    }
                    else {
                    	setVisible(false);
                    }
                    
                	break; // Sal del bucle ya que las credenciales son correctas
                	
                } 
                
                // Cierra el BufferedReader después de leer
                reader.close();

            } catch (IOException e) {
                // Maneja cualquier excepción de entrada/salida que pueda ocurrir
                System.out.println("Error al leer el archivo: " + e.getMessage());
            }
    	
    		cont++;
    	}
    	if (!datosCorrectos) {
            mensajeLabel.setText("Datos incorrectos");
            JOptionPane.showMessageDialog(null, mensajeLabel.getText());
            setVisible(false);
        }
    	System.out.println("UserCorres"+usuarioCorrespondiente);
    	
    }
   
    
    
    
    public static void main(String[] args) {  
    	Registro miVentana = new Registro();
        miVentana.setSize(900, 800);
        miVentana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        miVentana.setVisible(true);
    }
}
